import React, { useState } from 'react';
import {
  SlidersHorizontal,
  Layout,
  Code2,
  Palette,
  Type,
  FileCode,
  Check,
  X,
  Sparkles,
  Download,
  Copy,
  ExternalLink
} from 'lucide-react';
import { ThemeSettings } from '../types';

interface WpCustomizerBarProps {
  themeSettings: ThemeSettings;
  setThemeSettings: React.Dispatch<React.SetStateAction<ThemeSettings>>;
}

export const WpCustomizerBar: React.FC<WpCustomizerBarProps> = ({
  themeSettings,
  setThemeSettings
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'mode' | 'palette' | 'code'>('mode');
  const [copiedCode, setCopiedCode] = useState(false);

  const wpStyleCss = `/*
Theme Name: BanglaVenture - Modern Bangladesh Travel Blog Theme
Theme URI: https://banglaventure.travel/wp-theme
Author: BanglaVenture WordPress Craftsmen
Author URI: https://banglaventure.travel
Description: A modern, ultra-responsive, SEO-friendly WordPress travel blog theme focused on Bangladesh tourism (Cox's Bazar, Sundarbans, Sajek Valley, Saint Martin, Sylhet). Compatible with Elementor, Gutenberg, WooCommerce, and Yoast SEO.
Version: 2.6.0
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: banglaventure
Tags: travel, blog, bangladesh, tourism, grid-layout, custom-colors, elementor-ready, gutenberg-optimized, seo-friendly
*/`;

  const schemaJsonLd = `{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": "https://banglaventure.travel/#website",
      "url": "https://banglaventure.travel/",
      "name": "BanglaVenture",
      "description": "Discover Bangladesh: World's Longest Sea Beach, Sajek Cloud Kingdom & Mangrove Tigers",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://banglaventure.travel/?s={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    },
    {
      "@type": "TouristDestination",
      "name": "Cox's Bazar Sea Beach",
      "description": "The world's longest unbroken natural sand beach stretching 120 km along the Bay of Bengal.",
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 21.4272,
        "longitude": 92.0058
      },
      "touristType": ["EcoTourism", "BeachTourism", "MarineDrive"]
    }
  ]
}`;

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed bottom-4 left-4 z-40">
      {/* Trigger floating button */}
      {!isOpen && (
        <button
          id="wp-customizer-trigger-btn"
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-slate-900 dark:bg-emerald-950 text-white border border-emerald-500/50 shadow-2xl hover:scale-105 transition-all text-xs font-bold"
          title="WordPress Customizer & Elementor Simulator"
        >
          <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
          <span>WP Customizer ({themeSettings.wpMode})</span>
        </button>
      )}

      {/* Customizer Panel Drawer */}
      {isOpen && (
        <div className="w-[340px] sm:w-[420px] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4 animate-in slide-in-from-bottom-3 duration-200 text-slate-900 dark:text-white">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-xs">
                W
              </div>
              <div>
                <h4 className="font-bold text-sm leading-tight">WordPress Theme Studio</h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Elementor, Gutenberg & Schema Inspector
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Sub Navigation Tabs */}
          <div className="grid grid-cols-3 gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setActiveTab('mode')}
              className={`py-1.5 rounded-lg transition-colors ${
                activeTab === 'mode'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              View Mode
            </button>
            <button
              onClick={() => setActiveTab('palette')}
              className={`py-1.5 rounded-lg transition-colors ${
                activeTab === 'palette'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Color Theme
            </button>
            <button
              onClick={() => setActiveTab('code')}
              className={`py-1.5 rounded-lg transition-colors ${
                activeTab === 'code'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              WP Code
            </button>
          </div>

          {/* Tab 1: WP Mode Selector */}
          {activeTab === 'mode' && (
            <div className="space-y-2 text-xs">
              <p className="text-slate-500 dark:text-slate-400 font-medium">
                Select visual preview mode for theme builders:
              </p>

              {[
                {
                  id: 'standard',
                  name: 'Standard Theme View',
                  desc: 'Clean production WordPress frontend with full speed.'
                },
                {
                  id: 'elementor',
                  name: 'Elementor Visual Builder Mode',
                  desc: 'Simulates Elementor widget containers and column bounds.'
                },
                {
                  id: 'gutenberg',
                  name: 'Gutenberg Block Editor Preview',
                  desc: 'Displays WordPress block hierarchy and cover blocks.'
                }
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() =>
                    setThemeSettings((prev) => ({
                      ...prev,
                      wpMode: m.id as any
                    }))
                  }
                  className={`w-full text-left p-3 rounded-2xl border transition-all ${
                    themeSettings.wpMode === m.id
                      ? 'border-emerald-600 bg-emerald-50/60 dark:bg-emerald-950/40 ring-1 ring-emerald-500'
                      : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>{m.name}</span>
                    {themeSettings.wpMode === m.id && (
                      <Check className="w-4 h-4 text-emerald-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {m.desc}
                  </p>
                </button>
              ))}
            </div>
          )}

          {/* Tab 2: Color Palette Switcher */}
          {activeTab === 'palette' && (
            <div className="space-y-3 text-xs">
              <p className="text-slate-500 dark:text-slate-400 font-medium">
                Palette inspired by Bangladesh's natural landscapes:
              </p>

              {[
                {
                  id: 'emerald-blue',
                  name: 'Bengal Emerald & Sky Blue (Default)',
                  colors: ['#059669', '#0284c7', '#ffffff']
                },
                {
                  id: 'sundarbans',
                  name: 'Sundarbans Deep Forest & Amber',
                  colors: ['#065f46', '#d97706', '#0f172a']
                },
                {
                  id: 'sajek-sunset',
                  name: 'Sajek Sunset & Coral Clouds',
                  colors: ['#e11d48', '#f59e0b', '#4f46e5']
                }
              ].map((pal) => (
                <button
                  key={pal.id}
                  onClick={() =>
                    setThemeSettings((prev) => ({
                      ...prev,
                      colorScheme: pal.id as any
                    }))
                  }
                  className={`w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between ${
                    themeSettings.colorScheme === pal.id
                      ? 'border-emerald-600 bg-emerald-50/60 dark:bg-emerald-950/40'
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <div>
                    <p className="font-bold">{pal.name}</p>
                    <div className="flex gap-1.5 mt-1.5">
                      {pal.colors.map((c, i) => (
                        <span
                          key={i}
                          style={{ backgroundColor: c }}
                          className="w-4 h-4 rounded-full border border-slate-300 shadow-xs"
                        />
                      ))}
                    </div>
                  </div>
                  {themeSettings.colorScheme === pal.id && (
                    <Check className="w-4 h-4 text-emerald-600" />
                  )}
                </button>
              ))}
            </div>
          )}

          {/* Tab 3: WP Code & Schema JSON-LD */}
          {activeTab === 'code' && (
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-500">SEO Schema JSON-LD & style.css:</span>
                <button
                  onClick={() => handleCopyCode(schemaJsonLd)}
                  className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded font-semibold text-[10px] flex items-center gap-1"
                >
                  {copiedCode ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCode ? 'Copied' : 'Copy JSON-LD'}</span>
                </button>
              </div>

              <pre className="p-3 bg-slate-950 text-emerald-400 rounded-xl text-[10px] font-mono overflow-x-auto max-h-40 border border-slate-800">
                {schemaJsonLd}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
